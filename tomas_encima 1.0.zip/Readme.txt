========================================================tomas_encima.exe================================================================================================
tomas_encima.exe es un virus "prank" que no le va a hacer ningún tipo de daño a tu ordenador. Está creado con fines de diversión, y unas cuantas risas.
Tiene una fácil solución y no tendrás que hacer mucho trabajo.
Nota: Es para Windows    
(Virus BioCoded by Tomás Plaza)

========================================================Estado==========================================================================================================
Está en estado de desarrollo, y estoy dispuesto a cambiar cualquier cosa. También va por los bugs, y esas cosas. (tomy10masterpro@gmail.com)

========================================================Guía============================================================================================================
Antes de nada, pon la carpeta "tomas_encima.exe" en el directorio "C:". Una vez instalado, simplemente, dále a "tomas_encima.exe". Te saldrá un menú con todas las cosas, 
y es bastante intuitivo. Pero ten cuidado con lo que tocas... >:) Ah, y también, para todo el funcionamiento, ejecuta como administrador. 

========================================================Programación====================================================================================================
Es un programa básico que utiliza BatchFile, Visual Basic Script y una imágen.

========================================================Solución========================================================================================================
Para curarlo, ejecuta "Antivirus.bat" y reinicia tu PC.
ADVERTENCIA: Si tu ordenador no tiene reinicio manual, no lo ejecutes. Es difícil de controlar cuando le dejas mucho tiempo.

========================================================Advertencias====================================================================================================
Por mucho que no le haga daño al ordenador, el virus sigue teniendo algunas advertencias por si acaso. 

No lo ejecutes si:
- Tu ordenador no tiene reinicio manual. Es difícil de controlar cuando le dejas mucho tiempo.
- Tienes poco espacio de almacenamiento
- Tu ordenador va muy lento

=======================================================Payloads=========================================================================================================
· Ventanas de CMD
· Ventanas de msgbox
· Crea directorios a lo loco
· Crea perfiles con nombres aleatorios (La contraseña es "infectado")
· Te llena el escritorio de arhivos (Y te borra los que tienes)
· etc. 
========================================================Créditos========================================================================================================
Gracias a Raccine por el menú principal, y algunos códigos. :D
https://github.com/Neo23x0/Raccine

También a VectorStock por esta maravillosa imágen. :)
https://www.vectorstock.com

A Flaticon por el icono:
https://flaticon.com

Y a FlyTech por el efecto de las ventanas. 
https://www.youtube.com/user/TheLD3H


¡Que tengas un gran día!

tomy10masterpro@gmail.com
www.tomasplaza.es
Atentamente, Tomás. :D        